This is a model of a AIM-9L sidewinder missile

The archive includes the model in obj format and the skin in png format
and blend and xcf files are also included. Modeled using Blender 2.49b

Note: This Missile is 2.85 meters long

licence:

GNU GPL v2 (or at your option any later version)

Author is Mystic Mike (Mike Hosker)

Have Fun!!








